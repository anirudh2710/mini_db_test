#include "index/btree/BTreeInternal.h"

#include "storage/VarlenDataPage.h"

namespace taco {

void
BTreeMetaPageData::Initialize(char *btmeta_buf, PageNumber root_pid) {
    auto btmeta = (BTreeMetaPageData *) btmeta_buf;
    btmeta->m_root_pid = root_pid;
}

void
BTreePageHeaderData::Initialize(char *pagebuf,
                                uint16_t flags,
                                PageNumber prev_pid,
                                PageNumber next_pid) {
    VarlenDataPage::InitializePage(pagebuf, BTreePageHeaderSize);
    VarlenDataPage pg(pagebuf);
    BTreePageHeaderData *btpghdr = (BTreePageHeaderData *) pg.GetUserData();
    btpghdr->m_flags = flags;
    btpghdr->m_prev_pid = prev_pid;
    btpghdr->m_next_pid = next_pid;
    btpghdr->m_totrlen = 0;
}

BufferId
BTree::CreateNewBTreePage(bool isroot,
                          bool isleaf,
                          PageNumber prev_pid,
                          PageNumber next_pid) {
    // TODO implement it
    {
        char *pagebuf;
        PageNumber pageNumber = m_file->AllocatePage();
        BufferId bufid = g_bufman->PinPage(pageNumber, &pagebuf);
        VarlenDataPage pg(pagebuf);
        BTreePageHeaderData *btreehead = (BTreePageHeaderData *)pg.GetUserData();
        btreehead->m_prev_pid = prev_pid;
        btreehead->m_next_pid = next_pid;
        btreehead->m_totrlen = 0;
        if (isroot && isleaf)
        {
            btreehead->m_flags = BTREE_PAGE_ISROOT | BTREE_PAGE_ISLEAF;
        }
        else if (isroot && !isleaf)
        {
            btreehead->m_flags = BTREE_PAGE_ISROOT;
        }
        else if (!isroot && isleaf)
        {
            btreehead->m_flags = BTREE_PAGE_ISLEAF;
        }
        return bufid;
    }
}

BufferId
BTree::GetBTreeMetaPage() {
    // TODO implement it
    PageNumber pid = m_file ->GetFirstPageNumber();
    char *buffer;
    BufferId BUFID = g_bufman ->PinPage(pid, &buffer);
    return BUFID;
}

void
BTree::CreateLeafRecord(const IndexKey *key,
                        const RecordId &recid,
                        maxaligned_char_buf &recbuf) {
    // TODO implement it
}

void
BTree::CreateInternalRecord(const Record &child_recbuf,
                            PageNumber child_pid,
                            bool child_isleaf,
                            maxaligned_char_buf &recbuf) {
    // TODO implement it
}

}   // namespace taco
